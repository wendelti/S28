chrome.runtime.sendMessage({ Tipo: "iniciar" });

